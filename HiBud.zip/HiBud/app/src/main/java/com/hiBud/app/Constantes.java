package com.hiBud.app;

public class Constantes {
    public static final String URL_FOTO_POR_DEFECTO_USUARIOS = "https://i.ibb.co/Y0mkCqb/icon-logo.png";
    public static final String NODO_USUARIOS = "Usuarios";
}